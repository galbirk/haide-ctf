#### Goals
 * Try to find the flag